import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-add-book',
    templateUrl: './add-book.component.html',
    styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {

    public form: FormGroup;

    constructor(private fb: FormBuilder, private http:HttpClient) {
        this.form = this.fb.group({
            bookName: ["", Validators.required],
            author: ["", Validators.required],
            bookFile: [null, Validators.required]
        })
    }

    ngOnInit() {

    }

    save(files:FileList) {
        if (this.form.valid) {
            console.log("valid")
            let formData: FormData = new FormData();
            if(files.length > 0){
                formData.set('bookFile', files[0], files[0].name);
            }
            formData.set('bookName', this.form.value.bookName);
            formData.set('author', this.form.value.author);

            this.http.post<any>("http://localhost:58872/api/books",formData)
            .subscribe(
                res=>console.log(res),
                err=>console.log(err)
            )

        } else {
            console.log("Invalid");
        }
    }
}
