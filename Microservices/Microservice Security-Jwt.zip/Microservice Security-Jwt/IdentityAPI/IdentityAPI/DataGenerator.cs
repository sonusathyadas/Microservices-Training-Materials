﻿using IdentityAPI.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using IdentityAPI.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Builder;

namespace IdentityAPI
{
    public class DataGenerator
    {
        public static void Initialize(IApplicationBuilder app)
        {
            using (var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope())
            {
                var serviceProvider = serviceScope.ServiceProvider;

                using (var context = new AuthDbContext(serviceProvider.GetRequiredService<DbContextOptions<AuthDbContext>>()))
                {
                    if (context.Users.Any() || context.Scopes.Any() || context.Roles.Any())
                    {
                        return;   // Data was already seeded
                    }

                    context.Users.AddRange(
                        new UserModel { Username = "sonusathyadas", Password = "Password@123", EmailAddress = "sonusathyadas@gmail.com", Fullname = "Sonu Sathyadas" },
                        new UserModel { Username = "adityasonu", Password = "Password@123", EmailAddress = "adityasonu@gmail.com", Fullname = "Aditya Sonu" },
                        new UserModel { Username = "ashvinishahane", Password = "Password@123", EmailAddress = "ashvini@gmail.com", Fullname = "Ashvini Shahane" }
                        );

                    context.Roles.AddRange(
                        new UserRole { Username = "sonusathyadas", Role = "admin" },
                        new UserRole { Username = "sonusathyadas", Role = "manager" },
                        new UserRole { Username = "adityasonu", Role = "developer" },
                        new UserRole { Username = "ashvinishahane", Role = "manager" }
                        );
                    context.Scopes.AddRange(
                        new UserScope { Username = "sonusathyadas", Scope = "products" },
                        new UserScope { Username = "sonusathyadas", Scope = "orders" },
                        new UserScope { Username = "ashvinishahane", Scope = "orders" },
                        new UserScope { Username = "adityasonu", Scope = "products" }
                        );
                    context.SaveChanges();
                }
            }
        }
    }
}
