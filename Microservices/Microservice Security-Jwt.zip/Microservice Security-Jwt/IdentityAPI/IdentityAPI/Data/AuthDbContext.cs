﻿using IdentityAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityAPI.Data
{
    public class AuthDbContext : DbContext
    {
        public AuthDbContext(DbContextOptions<AuthDbContext> options) : base(options)
        { }

        public DbSet<UserModel> Users{get;set;}

        public DbSet<UserRole> Roles { get; set; }

        public DbSet<UserScope> Scopes { get; set; }
    }
}
