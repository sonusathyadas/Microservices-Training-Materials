﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using IdentityAPI.Data;
using IdentityAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace IdentityAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private IConfiguration config;
        private AuthDbContext db;
        public AuthController(IConfiguration configuration, AuthDbContext db)
        {
            this.config = configuration;
            this.db = db;
        }

        // GET api/auth/login
        [HttpPost]
        public IActionResult Login(LoginModel login)
        {
            IActionResult response = Unauthorized();
            var user = db.Users.SingleOrDefault(u => u.Username == login.Username && u.Password == login.Password);

            if (user != null)
            {
                var tokenString = GenerateJwtToken(user);
                response = Ok(new { token = tokenString });
            }

            return response;
        }

        private string GenerateJwtToken(UserModel userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Secret"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new List<Claim> {
                new Claim(JwtRegisteredClaimNames.Sub, userInfo.Username),
                new Claim(JwtRegisteredClaimNames.Email, userInfo.EmailAddress),                
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())                
            };
            //Adding roles to token claim
            var roles = db.Roles.Where(u => u.Username == userInfo.Username).Select(s=>s.Role);
            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }

            //Adding scopes to token claim
            var scopes = db.Scopes.Where(u => u.Username == userInfo.Username).Select(s => s.Scope);
            foreach (var scope in scopes)
            {
                claims.Add(new Claim(JwtRegisteredClaimNames.Aud, scope));
            }

            var token = new JwtSecurityToken(config["Jwt:Issuer"],
              null,
              claims,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }
}
