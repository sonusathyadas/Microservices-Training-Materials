﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using EventAPI.Infrastructure;
using EventAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;

namespace EventAPI.Controllers
{
    
    //[EnableCors("MSPolicy")]
    [Route("api/[controller]")] //route prefix
    [ApiController]
    public class EventsController : ControllerBase
    {
        private EventDbContext db;

        public EventsController(EventDbContext dbContext)
        {
            db = dbContext;
        }

        //GET /api/events  
        [Produces("text/json", "text/xml")]
        [HttpGet(Name ="GetAll")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        public ActionResult<List<EventInfo>> GetEvents()
        {
            var events = db.Events.ToList();
            return Ok(events); //returns with status code 200
        }

        //POST /api/events
        [Authorize]
        [HttpPost(Name ="AddEvent")]
        [ProducesResponseType((int)HttpStatusCode.Created)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<EventInfo>> AddEventAsync([FromBody]EventInfo eventInfo)
        {
            if (ModelState.IsValid)
            {
                var result = await db.Events.AddAsync(eventInfo);
                await db.SaveChangesAsync();
                return CreatedAtRoute("GetById", new { id = result.Entity.Id }, result.Entity);
                //return CreatedAtAction(nameof(GetEvent), new { id=result.Entity.Id }, result.Entity);
                //return Created("", result.Entity); // returns the status code 201
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        //GET /api/events/{id}
        [HttpGet("{id}", Name ="GetById")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        public async Task<ActionResult<EventInfo>> GetEventAsync([FromRoute] int id)
        {
            var eventInfo = await db.Events.FindAsync(id);
            if (eventInfo != null)
                return Ok(eventInfo);
            else
                return NotFound("Item you are searching not found");
        }
    }
}