import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class EventService {

    private readonly BASE_URL:string = "http://localhost:58193/api/events";

    constructor(private http:HttpClient) { }

    getAllEvents():Observable<any>{
        return this.http.get(this.BASE_URL);
    }

    addNewEvent(event:any):Observable<any>{
        let token = localStorage.getItem("auth_token");
        return this.http.post(this.BASE_URL, event, {
            headers:{
                "Content-Type":"application/json",
                "Accept":"application/json",
                "Authorization":`Bearer ${token}`
            }
        })
    }
}
