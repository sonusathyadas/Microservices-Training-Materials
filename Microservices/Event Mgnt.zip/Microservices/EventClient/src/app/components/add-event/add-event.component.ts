import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EventService } from 'src/app/services/event.service';

@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.css']
})
export class AddEventComponent implements OnInit {

    form:FormGroup;

    constructor(private fb:FormBuilder, private eventService:EventService) { }

    ngOnInit() {
        this.form = this.fb.group({
            "title":["", Validators.required],
            "speaker":["", Validators.required],
            "startDate":["", Validators.required],
            "endDate":["", Validators.required],
            "startTime":["", Validators.required],
            "endTime":["", Validators.required],
            "host":["", Validators.required],
            "registrationUrl":["", Validators.required]
        })
    }

    addEvent(){
        if(this.form.valid){
            this.eventService.addNewEvent(this.form.value)
            .subscribe(
                result=>{
                    console.log(result);
                    alert("added successfully");
                },
                err=>{
                    console.log(err);
                    alert("Error");
                }
            )
        }else{
            alert("Invalid form data");
        }
    }
}
