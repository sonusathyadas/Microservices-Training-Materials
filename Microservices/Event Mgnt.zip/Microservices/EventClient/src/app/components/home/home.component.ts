import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { EventService } from 'src/app/services/event.service';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    public events: Observable<any>;

    constructor(private eventService:EventService) { }

    ngOnInit() {
        this.events = this.eventService.getAllEvents();
    }

}
