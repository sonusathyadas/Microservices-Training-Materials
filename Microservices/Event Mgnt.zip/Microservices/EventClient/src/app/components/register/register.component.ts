import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';

@Component({
    selector: 'app-register',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

    form:FormGroup;

    constructor(private fb:FormBuilder, private userService:UserService) { }

    ngOnInit() {
        this.form = this.fb.group({
            "firstName":["", Validators.required],
            "lastName":["", Validators.required],
            "email":["", Validators.required],
            "password":["", Validators.required]
        })
    }

    register(){
        if(this.form.valid){
            this.userService.registerUser(this.form.value)
            .subscribe(
                result=>{ 
                    alert("Successfully registered");
                    console.log(result);
                },
                err=>{
                    alert("error");
                    console.log(err);
                }
            )
        }else{
            alert("Invalid form");
        }
    }
}
